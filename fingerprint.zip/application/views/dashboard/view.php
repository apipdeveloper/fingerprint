<tr>
<td>Data Tingkat</td>
<td id="tingkat"><?= $tingkat;?></td>
<td>
  <button class="btn btn-info" type="button" onclick="tingkat();"><i class="fas fa-sync"></i></button>
</td>
</tr>

<tr>
<td>Data Kelas</td>
<td id="kelas"><?= $kelas;?></td>
<td>
  <button class="btn btn-info" type="button" onclick="kelas();"><i class="fas fa-sync"></i></button>
</td>
</tr>

<tr>
<td>Data Pegawai</td>
<td id="pegawai"><?= $pegawai;?></td>
<td>
  <button class="btn btn-info" type="button" onclick="pegawai();"><i class="fas fa-sync"></i></button>
</td>
</tr>

<tr>
<td>Data Siswa</td>
<td id="siswa"><?= $siswa;?></td>
<td>
  <button class="btn btn-info" type="button" onclick="siswa();"><i class="fas fa-sync"></i></button>
</td>
</tr>