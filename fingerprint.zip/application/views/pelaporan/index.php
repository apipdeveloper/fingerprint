<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0"><?= $title; ?></h1>
          </div><!-- /.col -->
          
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        
        <div class="col-md-12 mt-4">
        <div class="card card-success card-outline">
              <div class="card-header">

							<div class="btn-group float-right">
								<a href="" class="btn btn-info"><i class="fas fa-sync"></i> Syncron SISTER</a>
								<a href="" class="btn btn-success"><i class="fas fa-sync"></i> Syncron JIBAS</a>
							</div>
                
              </div>
              <div class="card-body">
               
                <div class="table-responsive">	        		

                  <table id="example2" class="table table-bordered table-hover">
                  	
                        <thead>
                          <tr>
													<th>#</th>
                            <th>NIS</th>
                            <th>Nama</th>
														<th>Kelas</th> 
														<th>Tanggal</th>
														<th>Status</th>
                          </tr>
                        </thead>
                         <tbody id="v_siswa">
												 <?php $no = 1; foreach ($absen as $row): ?>

														<tr>
															<td><?= $no++; ?></td>	
															<td><?= $row->pin; ?></td>
															<td><?= $row->nama; ?></td>
															<td><?= $row->kelas; ?></td>
															<td><?= date('d-m-y',strtotime($row->date_in)); ?></td>
															<td>
																<div class="form-group">
																	<select name="status" class="form-control">
																		<option value="" selected disabled>::Status::</option>
																		<option value="H">H</option>
																		<option value="I">I</option>
																		<option value="S">S</option>
																		<option value="A">A</option>
																		<option value="C">C</option>
																	</select>
																</div>
															</td>
														</tr>	
															
														<?php endforeach ?>
                        </tbody>
                        

                  </table>
                </div>

              </div>
              <!-- /.card -->
            </div>
        </div>
       
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
