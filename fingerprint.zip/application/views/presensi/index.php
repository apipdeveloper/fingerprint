<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0"><?= $title; ?></h1>
          </div><!-- /.col -->
          
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        
        <div class="col-md-12 mt-4">
        <div class="card card-success card-outline">
              <div class="card-header">
                
							<div class="row">
								<div class="col-md-2">
									<label>
										Pilih Perangkat
									</label>
								</div>
								<div class="col-md-4">
									<select name="ip" id="ip" class="form-control">
									<option value="" selected disabled>Pilih Mesin</option>
										<?php foreach($mesin as $m):?>
											<option value="<?= $m['ip_address'];?>"><?= $m['nama_mesin'];?></option>
										<?php endforeach;?>										
									</select>
								</div>
								<div class="col">
									<div class="btn btn-group">
										<button onclick="masuk()" class="btn btn-success"><i class="fas fa-download"></i> Tarik Data Masuk</button>
										<button onclick="keluar()" class="btn btn-danger"><i class="fas fa-download"></i> Tarik Data Keluar</button>
										<a href="<?=base_url('Presensi/syncron');?>" class="btn btn-info"><i class="fas fa-sync"></i> Syncron JIBAS</a>
									</div>
								</div>
							</div>

              </div>
              <div class="card-body">
               
                <div class="table-responsive">	        		

                  <table id="example2" class="table table-striped table-hover">
                  	
                        <thead class="bg-primary">
                          <tr>                          
                            <th>#</th>
                            <th>Mesin</th>
                            <th>NIS</th>
                            <th>Nama</th>
														<th>Kelas</th> 
														<th>Tanggal</th>                           
                            <th>Masuk</th>
                            <th>Keluar</th>
														<th>Status</th>
                          </tr>
                        </thead>
                         <tbody id="view">
                          
                        </tbody>
                        

                  </table>
                </div>

              </div>
              <!-- /.card -->
            </div>
        </div>
       
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  

<script>

  view();
function view(){

  $.get( "<?= base_url('Presensi/view');?>", function( data ) {
			$( "#view" ).html( data );
		});
	}

	function masuk(){
		var ip = $("#ip").val();
		if(ip === null){
			alert('Pilih Mesin');
		}else{
			window.location.href = '<?= base_url("Presensi/getLogIn/");?>'+ip;			
		}		
	}

	function keluar(){
		var ip = $("#ip").val();
		if(ip === null){
			alert('Pilih Mesin');
		}else{
		window.location.href = '<?= base_url("Presensi/getLogOut/");?>'+ip;
		}
	}
    

</script>

      