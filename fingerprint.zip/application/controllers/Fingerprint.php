<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

// require FCPATH . 'vendor/autoload.php';
use TADPHP\TAD;
use TADPHP\TADFactory;
use TADPHP\TADResponse;
use TADPHP\Providers\TADSoap;
use TADPHP\Providers\TADZKLib;
use TADPHP\Providers\FilterArgumentError;
// use TADPHP\Providers\UnrecognizedArgument;
// use TADPHP\Providers\UnrecognizedCommand;

error_reporting(0);

class Fingerprint extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		is_login();
	}

	public function index()
	{
		$data = [
				'title' 	=> 'Data User',		
				'member' 	=> $this->db->select('*')
								->from('tbl_member m')
								->join('tbl_siswa s','s.nis = m.nis')
								->get()->result(),

				'kelas' 	=> $this->db->get('kelas')->result(),
				'mesin' 	=> $this->db->get('ip_mesin')->result(),
				'pin' 		=> pin(),
			];

		$this->load->view('templates/header');
		$this->load->view('finger/index',$data);
		$this->load->view('templates/footer');
	}

	//get siswa
    public function getSiswa()
    {   
        $idkelas   = $this->input->post('id_kelas');
        //$response   = $this->db->get_where('tbl_siswa',['idkelas' => $idkelas])->result();
		$response = $this->db->select('*')
							 ->from('tbl_siswa')
							 ->where('idkelas', $idkelas)
							 ->order_by('nama','ASC')
							 ->get()->result();

        echo json_encode($response);
    }

	//get siswa by nis
    public function getSiswaByNis()
    {   
        $nis   = $this->input->post('nis');
        $response   = $this->db->get_where('tbl_siswa',['nis' => $nis])->row();
        echo json_encode($response);
    }

    public function add_user()
	{	
		$ip = $this->input->post('ip');
		$pin = $this->input->post('pin');
		$options = [
			'ip' => $ip,
			'com_key' => 0,
			'soap_port' => 80
		];
		$tad = new TADFactory($options);
		$con = $tad->get_instance();
		if ($con->is_alive()) {

			$cek = $con->get_user_info(['pin'=>$pin])->to_array();

			if(empty($cek)){
				
				$r = [
					    'pin' => $pin,
					    'name'=> $this->input->post('nama'),
					    'privilege'=> 2,
					    'password' => 123
					];

				$user = $con->set_user_info($r);

				$query =  $this->db->insert('tbl_member',[
								'pin' => $pin,
								'nis' => $this->input->post('nis'),	
							]);

				$res = ['status' => 200,'message' =>'Data berhasil disimpan!'];
				
			}else{
				$res = ['status' => 201, 'message'=>'Data sudah ada'];
				
			}

			$this->session->set_flashdata('message', $res["message"]);
            redirect('Fingerprint');

		} else {

			$this->session->set_flashdata('error', 'Fingerprint not connected');
            redirect('Fingerprint');
		}
		
	}

	//delete user
	public function del_user($pin)
	{	
		$ip = $this->input->post('ip');

		$options = [
			'ip' => $ip,
			'com_key' => 0,
			'soap_port' => 80
		];

		$tad = new TADFactory($options);
		$con = $tad->get_instance();
		if ($con->is_alive()) {

			$usr = [
				    'pin' => $pin
				];

			$user = $con->delete_user($usr);
			$query = $this->db->where('pin',$pin)->delete('tbl_member');

			$this->session->set_flashdata('message', 'Data berhasil dihapus.');
            redirect('Fingerprint');

			

		} else {
			$this->session->set_flashdata('error', 'Fingerprint not connected');
            redirect('Fingerprint');
		}
		
	}

	public function add_perkelas($id_kelas){

		$siswa = $this->db->get_where('tbl_siswa',[
			'idkelas' => $id_kelas
		])->result();
		
		$pin = 0;
		foreach ($siswa as $row) {
			$pin = $pin++;
			$nis = $row->nis;
			$name = $row->nama;

			$query = $this->generate($pin, $nis, $name);
			if($query){
				$res = ['status' => 200,'message' =>'Data berhasil disimpan!'];
                echo json_encode($res);
			}else{
				$res = ['status' => 201,'message'=>'Data sudah ada'];
                echo json_encode($res);
			}

		}
	}

	public function generate($pin,$nis,$name)
	{	
		$ip = $this->input->post('ip');
		$pin = $this->input->post('pin');
		$options = [
			'ip' => $ip,
			'com_key' => 0,
			'soap_port' => 80
		];
		$tad = new TADFactory($options);
		$con = $tad->get_instance();
		if ($con->is_alive()) {

			$cek = $con->get_user_info(['pin'=>$pin])->to_array();

			if(empty($cek)){
				
				$r = [
					    'pin' => $pin,
					    'name'=> $name,
					    'privilege'=> 2,
					    'password' => 123
					];

				$user = $con->set_user_info($r);

				$query =  $this->db->insert('tbl_member',[
								'pin' => $pin,
								'nis' => $nis,	
							]);

				$res = ['status' => 200,'message' =>'Data berhasil disimpan!'];
				echo json_encode($res);
			}else{
				$res = ['status' => 201, 'message'=>'Data sudah ada'];
				echo json_encode($res);
			}

		} else {

			$res = ['status' => 502,'message'=>'fingerprint not connected'];
			echo json_encode($res);
		}
		
	}

	

}

/* End of file Fingerprint.php */
/* Location: ./application/controllers/Fingerprint.php */
