<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require FCPATH . 'vendor/autoload.php';
use TADPHP\TAD;
use TADPHP\TADFactory;
use TADPHP\TADResponse;
use TADPHP\Providers\TADSoap;
use TADPHP\Providers\TADZKLib;
use TADPHP\Providers\FilterArgumentError;
// use TADPHP\Providers\UnrecognizedArgument;
// use TADPHP\Providers\UnrecognizedCommand;

error_reporting(0);

class Setting extends CI_Controller {

	public function __construct(){
		parent::__construct();

		is_login();
		$this->load->model('Mesin_model');
		$this->load->model('Log_model','LOG');
		
	}

	private function koneksi()
	{
		return $options = [
			'ip' => '192.168.5.201',
			'com_key' => 0,
			'soap_port' => 80
		];

		if ($con->is_alive()) {
			echo "connect to machine";

		} else {
			echo "can't connect to machine";
		}
	}

	

	public function index()
	{	

		$data=[
			'title' => "Setting",
			'mesin' => $this->db->get('ip_mesin')->result()
		];

		$this->form_validation->set_rules('nama_mesin','Nama Mesin','required');
		$this->form_validation->set_rules('ip_address','ip address','required');

		if ($this->form_validation->run()== false) {

			$this->load->view('templates/header');
			$this->load->view('setting/index',$data);
			$this->load->view('templates/footer');

		}else{

			$data = [
				'nama_mesin' => $this->input->post('nama_mesin'),
				'ip_address' => $this->input->post('ip_address')
			];

			$query = $this->Mesin_model->insert_mesin($data);

			if ($query == true) {

				$this->session->set_flashdata('message', "<script>flash_toast('success',' Berhasil,  Menyimpan Data.');</script>");
				
			}else{
					$this->session->set_flashdata('message', "<script>flash_toast('error',' Gagal,  Menyimpan Data.!');</script>");
			}
		}
		
		
	}

	public function editMesin($id)
	{
		$id = decrypt_url($id);

		$data = [
			'nama_mesin' => $this->input->post('nama_mesin'),
			'ip_address' => $this->input->post('ip_address'),
		];

		$query = $this->db->where('id_mesin', $id)->update('ip_mesin',$data);

		if ($query == true) {

				$this->session->set_flashdata('message', "<script>flash_toast('success','Berhasil,  Mengubah Data.');</script>");
				
		}else{
				$this->session->set_flashdata('message', "<script>flash_toast('error','Gagal,  Mengubah Data.!');</script>");
		}

		redirect('Mesin');
		

	}

	public function DeleteMesin($id)
	{
		$id = decrypt_url($id);		

		$query = $this->db->where('id_mesin', $id)->delete('ip_mesin');

		if ($query == true) {

				$this->session->set_flashdata('message', "<script>flash_toast('success','Berhasil,  Menghapus Data.');</script>");
				
		}else{
				$this->session->set_flashdata('message', "<script>flash_toast('error','Gagal,  Menghapus Data.!');</script>");
		}

		redirect('Mesin');
		

	}

	public function cek_koneksi($id)
	{	
		$id = decrypt_url($id);
		$mesin = $this->db->get_where('ip_mesin',['id_mesin' => $id])->row();

		$options = [
			'ip' => $mesin->ip_address,
			'com_key' => 0,
			'soap_port' => 80
		];

		$tad = new TADFactory($options);
		$con = $tad->get_instance();

		if ($con->is_alive()) {
			echo json_encode("200");

		} else {
			echo json_encode("500");
		}
	}

	public function getLogAll()
	{	
		$data['title'] = 'Dashboard';
		$mesin = $this->db->get_where('ip_mesin',['id_mesin' => $id])->row();

		$options = [
			'ip' => '192.168.0.201',
			'com_key' => 0,
			'soap_port' => 80
		];

		$tad = new TADFactory($options);
		$con = $tad->get_instance();
		if ($con->is_alive()) {
			$log = $con->get_att_log()->to_array();
			$sn	 = $con->get_serial_number()->to_array();
			$log = $log['Row'];
			$sn  = $sn['Row'];
			foreach ($log as $logs) {

				$date = date('Y-m-d',strtotime($logs['DateTime']));
				$time = date('H:i:s',strtotime($logs['DateTime']));

				$data = [
					'SN'=> $sn['Information'],
					'pin' => $logs['PIN'],
					'date' => $date,
					'time' => $time,
					'verified' => $logs['Verified'],
					'status' => $logs['Status'],
					'workcode' => $logs['WorkCode'],

				];

				$res[] = $this->LOG->insert($data);
			}
			
			var_dump($res);
		} else {
			echo "can't connect to machine";
		}
		
	}

	public function getLogByTgl()
	{	
		$tgl = $this->input->post('tanggal');
		$id_mesin = $this->input->post('id_mesin');

		// $mesin = $this->db->get_where('ip_mesin',['id_mesin' => $id_mesin])->row();
		$options = [
			'ip' => '192.168.0.201',
			'com_key' => 0,
			'soap_port' => 80
		];
		$tad = new TADFactory($options);
		$con = $tad->get_instance();
		$tgl = [
		    	'start' => '2019-10-21',
		    	'end' => '	2023-10-21'
		    ];

		if ($con->is_alive()) {

			$att_logs = $con->get_att_log();

			if ($att_logs->is_empty_response()) {
			    echo 'The employee does not have logs recorded';
			}else{
				
				$filter_logs = $att_logs->filter_by_date($tgl);

				echo json_encode($filter_logs);

			}
			

		} else {
			echo "can't connect to machine";
		}
		
	}

	public function getAllUser()
	{	
		$data['title'] = 'Dashboard';
		$options = [
			'ip' => '192.168.0.201',
			'com_key' => 0,
			'soap_port' => 80
		];
		$tad = new TADFactory($options);
		$con = $tad->get_instance();
		if ($con->is_alive()) {
			$user = $con->get_user_info()->to_array();
			
			$user =  $user['Row'];
				var_dump($user['Name']);
			// }
			// //$this->load->view('home/index',$data);

		} else {
			echo "can't connect to machine";
		}
		
	}

	public function get_template_all()
	{	
		$data['title'] = 'Dashboard';
		$options = [
			'ip' => '192.168.0.201',
			'com_key' => 0,
			'soap_port' => 80
		];
		$tad = new TADFactory($options);
		$con = $tad->get_instance();
		if ($con->is_alive()) {
			$user = $con->get_user_template()->to_array();
			
			
				var_dump($user);
			// }
			// //$this->load->view('home/index',$data);

		} else {
			echo "can't connect to machine";
		}
		
	}
//add user
	public function add_user()
	{	
		$data['title'] = 'Add User';
		$options = [
			'ip' => '192.168.0.201',
			'com_key' => 0,
			'soap_port' => 80
		];
		$tad = new TADFactory($options);
		$con = $tad->get_instance();
		if ($con->is_alive()) {

			$r = [
				    'pin' => 0,
				    'name'=> 'acunl',
				    'privilege'=> 2,
				    'password' => 123
				];

			$user = $con->set_user_info($r);
			echo"success";

			

		} else {
			echo "can't creat user";
		}
		
	}

	//delete user
	public function delete_user()
	{	
		$data['title'] = 'Add User';
		$options = [
			'ip' => '192.168.0.201',
			'com_key' => 0,
			'soap_port' => 80
		];
		$tad = new TADFactory($options);
		$con = $tad->get_instance();
		if ($con->is_alive()) {

			$usr = [
				    'pin' => $this->input->post('pin')
				];

			$user = $con->delete_user($usr);
			echo"success";

			

		} else {
			echo "can't creat user";
		}
		
	}

	//get template
	public function get_template()
	{	
		$data['title'] = 'Get Tamplate user';
		$options = [
			'ip' => '192.168.0.201',
			'com_key' => 0,
			'soap_port' => 80
		];
		$tad = new TADFactory($options);
		$con = $tad->get_instance();
		if ($con->is_alive()) {
			$user = $con->get_user_template()->to_array();
			
			
				var_dump($user);
			// }
			// //$this->load->view('home/index',$data);

		} else {
			echo "can't connect to machine";
		}
		
	}

	//add tamplate
	public function add_template()
	{	
		$data['title'] = 'Add Tamplate user';
		$options = [
			'ip' => '192.168.0.201',
			'com_key' => 0,
			'soap_port' => 80
		];
		$tad = new TADFactory($options);
		$con = $tad->get_instance();
		if ($con->is_alive()) {

			$template = [
				  'pin' => 123,
				  'finger_id' => 0, // First fingerprint has 0 as index.
				  'size' => 514,    // Be careful, this is not string length of $template1_vx9 var.
				  'valid' => 1,
				  'template' => $template1_vx9

				];

			$user = $con->set_user_template( $template );
			echo"success";

		} else {
			echo "can't creat user";
		}
		
	}

	//delete tamplate
	public function delete_template()
	{	
		$data['title'] = 'Add Tamplate user';
		$options = [
			'ip' => '192.168.0.201',
			'com_key' => 0,
			'soap_port' => 80
		];
		$tad = new TADFactory($options);
		$con = $tad->get_instance();
		if ($con->is_alive()) {

			$template = [
				  'pin' => 123,				  

				];

			$user = $con->delete_template( $template );
			echo"success";

		} else {
			echo "can't creat user";
		}
		
	}

	//delete data
	public function delete_data()
	{	
		$data['title'] = 'Add Tamplate user';
		$options = [
			'ip' => '192.168.5.201',
			'com_key' => 0,
			'soap_port' => 80
		];
		$tad = new TADFactory($options);
		$con = $tad->get_instance();
		if ($con->is_alive()) {

			$value= ['value' => 1 ];

			$con->delete_data( $value);
			echo"success";

		} else {
			echo "can't creat user";
		}
		
	}

	//statistik mesin
	public function info()
	{	
		$data['title'] = 'Add Tamplate user';
		$options = [
			'ip' => '192.168.0.201',
			'com_key' => 0,
			'soap_port' => 80
		];
		$tad = new TADFactory($options);
		$con = $tad->get_instance();
		if ($con->is_alive()) {
			$data = [

				'info'	=> $con->get_free_sizes()->to_array(),
				'sn'	=> $con->get_serial_number()->to_array(),
				'model'	=> $con->get_device_name()->to_array(),
				'mac'	=> $con->get_mac_address()->to_array(),
			];
			
			
			var_dump($data);

		} else {
			echo "koneksi gagal";
		}
		
	}


	//setting date
	public function tgl($ip)
	{	
		$data['title'] = 'tanggal';
		$options = [
			'ip' => $ip,
			'com_key' => 0,
			'soap_port' => 80
		];

		$tad = new TADFactory($options);
		$con = $tad->get_instance();
		if ($con->is_alive()) {			

			$tgl = [
				'date'=>date('Y-m-d'),
				'time'=>date('H:i:s')
			];

			$con->set_date($tgl);
			echo"success";		

		} else {
			echo "can't creat user";
		}
		
	}

}

/* End of file Mesin.php */
/* Location: ./application/controllers/Mesin.php */
