<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pelaporan extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		is_login();
		
	}

	public function index(){
		$data = [
			'title' => 'Pelaporan',
			'absen' =>  $this->db->select('*')
							->from('logs a')
							->join('tbl_member b','b.pin = a.pin')
							->join('tbl_siswa s','s.nis = b.nis')
							->where('a.pin < >','m.pin')
							->get()->result(),
		];
		$this->load->view('templates/header');
		$this->load->view('pelaporan/index',$data);
		$this->load->view('templates/footer');
	}
}
