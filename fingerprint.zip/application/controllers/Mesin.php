<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//require FCPATH . 'vendor/autoload.php';
use TADPHP\TAD;
use TADPHP\TADFactory;
use TADPHP\TADResponse;
use TADPHP\Providers\TADSoap;
use TADPHP\Providers\TADZKLib;
// use TADPHP\Providers\FilterArgumentError;
// use TADPHP\Providers\UnrecognizedArgument;
// use TADPHP\Providers\UnrecognizedCommand;

error_reporting(0);

class Mesin extends CI_Controller {

	public function __construct(){
		parent::__construct();

		is_login();
		$this->load->model('Mesin_model');
		$this->load->model('Log_model','LOG');
		
	}

	
	

	public function index()
	{	

		$data=[
			'title' => "Data Mesin",
			'mesin' => $this->db->get('ip_mesin')->result()
		];

		$this->form_validation->set_rules('nama_mesin','Nama Mesin','required');
		$this->form_validation->set_rules('ip_address','ip address','required');

		if ($this->form_validation->run()== false) {

			$this->load->view('templates/header');
			$this->load->view('mesin/index',$data);
			$this->load->view('templates/footer');

		}else{

			$data = [
				'nama_mesin' => $this->input->post('nama_mesin'),
				'ip_address' => $this->input->post('ip_address')
			];

			$query = $this->Mesin_model->insert_mesin($data);

			if ($query == true) {

				$this->session->set_flashdata('message', "<script>flash_toast('success',' Berhasil,  Menyimpan Data.');</script>");
				
			}else{
					$this->session->set_flashdata('message', "<script>flash_toast('error',' Gagal,  Menyimpan Data.!');</script>");
			}
		}
		
		
	}

	public function editMesin($id)
	{
		$id = decrypt_url($id);

		$data = [
			'nama_mesin' => $this->input->post('nama_mesin'),
			'ip_address' => $this->input->post('ip_address'),
		];

		$query = $this->db->where('id_mesin', $id)->update('ip_mesin',$data);

		if ($query == true) {

				$this->session->set_flashdata('message', "<script>flash_toast('success','Berhasil,  Mengubah Data.');</script>");
				
		}else{
				$this->session->set_flashdata('message', "<script>flash_toast('error','Gagal,  Mengubah Data.!');</script>");
		}

		redirect('Mesin');
		

	}

	public function DeleteMesin($id)
	{
		$id = decrypt_url($id);		

		$query = $this->db->where('id_mesin', $id)->delete('ip_mesin');

		if ($query == true) {

				$this->session->set_flashdata('message', "<script>flash_toast('success','Berhasil,  Menghapus Data.');</script>");
				
		}else{
				$this->session->set_flashdata('message', "<script>flash_toast('error','Gagal,  Menghapus Data.!');</script>");
		}

		redirect('Mesin');
		

	}

	//setting date
	public function tanggal($ip)
	{	
		
		$options = [
			'ip' => $ip,
			'com_key' => 0,
			'soap_port' => 80
		];

		$tad = new TADFactory($options);
		$con = $tad->get_instance();
		if ($con->is_alive()) {			

			$tgl = [
				'date'=>date('Y-m-d'),
				'time'=>date('H:i:s')
			];

			$con->set_date($tgl);
			$res = ['message' =>'200'];
			echo json_encode($res);		

		} else {
			$res = ['message' =>'404'];
			echo json_encode($res);
		}
		
	}

	

	


}

/* End of file Mesin.php */
/* Location: ./application/controllers/Mesin.php */
