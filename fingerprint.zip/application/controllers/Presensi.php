<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use TADPHP\TAD;
use TADPHP\TADFactory;
use TADPHP\TADResponse;
use TADPHP\Providers\TADSoap;
use TADPHP\Providers\TADZKLib;
use TADPHP\Providers\FilterArgumentError;

error_reporting(0);

class Presensi extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		is_login();
		
	}
	public function index()
	{
		$data=[
			'title' => "Data Presensi",
			'mesin' => $this->db->get('ip_mesin')->result_array(),
		];

		$this->load->view('templates/header');
		$this->load->view('presensi/index',$data);
		$this->load->view('templates/footer');

	}

	public function view()
	{	$data = [
			'absen' =>  $this->db->select('*')
							->from('logs a')
							->join('tbl_member b','b.pin = a.pin')
							->join('tbl_siswa s','s.nis = b.nis')
							->join('ip_mesin m','m.sn = a.SN')
							->where('flag','N')
							->get()->result(),
		];

		 $this->load->view('presensi/view',$data);

	}

	public function getLogIn($ip)
	{	
		$options = [
			'ip' => $ip,
			'com_key' => 0,
			'soap_port' => 80
		];

		$tad = new TADFactory($options);
		$con = $tad->get_instance();
		if ($con->is_alive()) {
			$log = $con->get_att_log()->to_array();
			$sn	 = $con->get_serial_number()->to_array();
			$log = $log['Row'];
			$sn  = $sn['Row'];
			foreach ($log as $logs) {

				//data fingerpirnt

				$SN = $sn['Information'];
				$pin = $logs['PIN'];
				$date = date('Y-m-d',strtotime($logs['DateTime']));
				$time = date('H:i:s',strtotime($logs['DateTime']));


				$cek_log = $this->db->get_where('logs',[
					'pin' => $pin,
					'date_in' => $date,
				])->num_rows();

				if ($cek_log > 0) {

					$res = ['status' => 201,'message' => 'Data sudah ada!'];

				}else{

					$this->db->insert('logs',[
						'SN' => $SN,
						'pin' => $pin,
						'date_in' => $date,
						'time_in' => $time,
						'flag' => 'N',
					]);

					$res = ['status' => 200,'message' => 'Data berhasil disimpan!'];
				}				

			}

			//delete log data
			$this->deleteLog($ip);

			
			$this->session->set_flashdata('message', $res["message"]);
            redirect('Presensi');
		} else {
			$this->session->set_flashdata('error', 'Fingerprint not connected');
            redirect('Presensi');
		}
		
	}

	public function getLogOut($ip)
	{	
		$options = [
			'ip' => $ip,
			'com_key' => 0,
			'soap_port' => 80
		];

		$tad = new TADFactory($options);
		$con = $tad->get_instance();
		if ($con->is_alive()) {
			$log = $con->get_att_log()->to_array();
			$sn	 = $con->get_serial_number()->to_array();
			$log = $log['Row'];
			$sn  = $sn['Row'];
			foreach ($log as $logs) {

				//data fingerpirnt

				$SN = $sn['Information'];
				$pin = $logs['PIN'];
				$date = date('Y-m-d',strtotime($logs['DateTime']));
				$time = date('H:i:s',strtotime($logs['DateTime']));


				$cek_log = $this->db->get_where('logs',[
					'pin' => $pin,
					'date_in' => $date,
				])->num_rows();

				if ($cek_log > 0) {

					$cek_out = $this->db->get_where('logs',[
						'pin' => $pin,
						'date_out' => $date,
					])->num_rows();

					if($cek_out > 0){
						//$res = ['status' => 201,'message' => 'Data cek out sudah ada!'];
					}else{

						$this->db->where(['pin' => $pin, 'date_in' => $date]);
						$this->db->update('logs',[
							'date_out' => $date,
							'time_out' => $time,
							'status' => 'H',
							
						]);

					$res = ['status' => 200,'message' => 'Data berhasil disimpan!'];
					}					

				}else{
					
					$res = ['status' => 201,'message' => 'Data presensi masuk tidak ada!'];
				}				

			}

			//delete log data
			$this->deleteLog($ip);

			$this->session->set_flashdata('message', $res["message"]);
            redirect('Presensi');
		} else {
			$this->session->set_flashdata('error', 'Fingerprint not connected');
            redirect('Presensi');
		}
		
	}

	//delete log
	public function deleteLog($ip)
	{	
		$ip = $ip;
		$options = [
			'ip' => $ip,
			'com_key' => 0,
			'soap_port' => 80
		];

		$tad = new TADFactory($options);
		$con = $tad->get_instance();
		if ($con->is_alive()) {

			//clear log mesin
			$del_log = $con->delete_data(['value' => 3 ]);

			$res = [
				'status' => 200,
				'message' => 'Successfully deleted'
			];
			$this->session->set_flashdata('message', $res["message"]);
            redirect('Presensi');
		} else {
			$this->session->set_flashdata('error', 'Fingerprint not connected');
            redirect('Presensi');
		}
		
	}

	public function syncron(){
		
		$absen =  $this->db->select('*')
						->from('logs a')
						->join('tbl_member b','b.pin = a.pin')
						->where('flag','N')
						->get()->result();
						       
		foreach($absen as $row){
			$pin = $row->pin;
			$nis = $row->nis;
			$date_in = $row->date_in;
			$time_in =  $row->time_in;
			$date_out = $row->date_out;
			$time_out = $row->time_out;

			$post = [
				'user' 		=> $nis,
				'date_in' 	=> $date_in,
				'time_in'   => $time_in,
				'date_out' 	=> $date_out,
				'time_out' 	=> $time_out,
			];

			
			$ch = curl_init('http://192.168.1.222/jibas/api/syncrone.php?key=@smkyapisda');
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
			
			// execute!
		$response[] = curl_exec($ch);
			
			// close the connection, release resources used
			curl_close($ch);
	
		}
		
		// do anything you want with your response
		// var_dump($response);

		$this->db->where(['pin'=>$pin, 'date_in'=>$date_in])->update('logs',['flag'=>'Y']);
		$this->session->set_flashdata('message', 'Sudah terkirim ke JIBAS presensi manager.');
        redirect('Presensi');

        
	}

}

/* End of file Presensi.php */
/* Location: ./application/controllers/Presensi.php */
