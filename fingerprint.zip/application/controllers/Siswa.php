<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Siswa extends CI_Controller {

	public function __construct(){
		parent::__construct();
		is_login();
	}

	public function index()
	{
		

		$data = [
				'title' => 'Data Siswa',
				'tingkat' 	=> $this->db->get('tingkat')->result(),
				'kelas' 	=> $this->db->get('kelas')->result(),		
				'siswa' => $this->db->get('tbl_siswa')->result(),
			];

		$this->load->view('templates/header');
		$this->load->view('siswa/index',$data);
		$this->load->view('templates/footer');
	}

	//get kelas
    public function getKelas()
    {   
        $id_tingkat = $this->input->post('id_tingkat');
        $response   = $this->db->get_where('kelas',['idtingkat'=> $id_tingkat])->result();
        echo json_encode($response);
    }

    //get kelas
    public function getSiswa()
    {   
        $idkelas   = $this->input->post('id_kelas');
        $response   = $this->db->get_where('tbl_siswa',['idkelas' => $idkelas])->result();
        echo json_encode($response);
    }

}

/* End of file Siswa.php */
/* Location: ./application/controllers/Siswa.php */
